import json
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict
from enum import Enum
from pathlib import Path

from models import (
    DiagnosticSession,
    DiagnosticEvidence,
    EvidenceStatus,
    Hypothesis,
)


DB_PATH = Path(__file__).resolve().parent / "diagnostic_lab.db"


class StorageError(Exception):
    pass


class SessionStorage:

    def __init__(self, db_path=DB_PATH):
        self.db_path = str(db_path)

        if self.db_path != ":memory:":
            Path(self.db_path).parent.mkdir(
                parents=True,
                exist_ok=True,
            )

        self.initialize()

    def connect(self):
        connection = sqlite3.connect(
            self.db_path,
            timeout=15,
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout = 15000")
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    @contextmanager
    def _connection(self, write=False):
        db = self.connect()

        try:
            if write:
                db.execute("BEGIN IMMEDIATE")

            yield db

            if write:
                db.commit()

        except Exception:
            if write:
                db.rollback()
            raise

        finally:
            db.close()

    def initialize(self):
        try:
            with self.connect() as db:
                if self.db_path != ":memory:":
                    db.execute("PRAGMA journal_mode = WAL")

                db.execute("""
                    CREATE TABLE IF NOT EXISTS diagnostic_sessions (
                        session_id TEXT PRIMARY KEY,
                        variant_id TEXT NOT NULL,
                        status TEXT NOT NULL,
                        session_data TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    )
                """)

                db.execute("""
                    CREATE INDEX IF NOT EXISTS
                    idx_diagnostic_sessions_variant
                    ON diagnostic_sessions(variant_id)
                """)

                db.commit()

        except sqlite3.Error as exc:
            raise StorageError(
                f"Ошибка инициализации SQLite: {exc}"
            ) from exc

    @staticmethod
    def _serialize_value(value):
        if isinstance(value, Enum):
            return value.value

        if isinstance(value, dict):
            return {
                str(key): SessionStorage._serialize_value(item)
                for key, item in value.items()
            }

        if isinstance(value, (list, tuple)):
            return [
                SessionStorage._serialize_value(item)
                for item in value
            ]

        return value

    def save_session(self, session):
        if not isinstance(session, DiagnosticSession):
            raise StorageError(
                "Ожидался объект DiagnosticSession."
            )

        if not session.session_id or not session.variant_id:
            raise StorageError(
                "session_id и variant_id обязательны."
            )

        try:
            data = self._serialize_value(asdict(session))

            payload = json.dumps(
                data,
                ensure_ascii=False,
                separators=(",", ":"),
                allow_nan=False,
            )

            with self._connection(write=True) as db:
                db.execute("""
                    INSERT INTO diagnostic_sessions (
                        session_id,
                        variant_id,
                        status,
                        session_data,
                        created_at,
                        updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, datetime('now'))
                    ON CONFLICT(session_id) DO UPDATE SET
                        variant_id = excluded.variant_id,
                        status = excluded.status,
                        session_data = excluded.session_data,
                        updated_at = datetime('now')
                """, (
                    session.session_id,
                    session.variant_id,
                    session.status,
                    payload,
                    session.created_at,
                ))

            return session.session_id

        except (sqlite3.Error, TypeError, ValueError) as exc:
            raise StorageError(
                f"Не удалось сохранить сессию: {exc}"
            ) from exc

    def load_session(self, session_id):
        try:
            with self._connection() as db:
                row = db.execute("""
                    SELECT session_data
                    FROM diagnostic_sessions
                    WHERE session_id = ?
                """, (session_id,)).fetchone()

            if row is None:
                return None

            data = json.loads(row["session_data"])

            required = {
                "session_id",
                "variant_id",
                "symptoms",
                "dtcs",
                "measurements",
                "evidence",
                "hypotheses",
                "test_history",
                "status",
                "created_at",
            }

            if not isinstance(data, dict):
                raise ValueError("Некорректная структура сессии.")

            missing = required - data.keys()

            if missing:
                raise ValueError(
                    f"Отсутствуют поля сессии: {sorted(missing)}"
                )

            if data["session_id"] != session_id:
                raise ValueError("Несовпадение session_id.")

            evidence = []

            for item in data["evidence"]:
                item = dict(item)
                item["status"] = EvidenceStatus(item["status"])
                evidence.append(DiagnosticEvidence(**item))

            hypotheses = [
                Hypothesis(**item)
                for item in data["hypotheses"]
            ]

            return DiagnosticSession(
                session_id=data["session_id"],
                variant_id=data["variant_id"],
                symptoms=data["symptoms"],
                dtcs=data["dtcs"],
                measurements=data["measurements"],
                evidence=evidence,
                hypotheses=hypotheses,
                test_history=data["test_history"],
                status=data["status"],
                created_at=data["created_at"],
            )

        except (
            sqlite3.Error,
            json.JSONDecodeError,
            TypeError,
            ValueError,
            KeyError,
        ) as exc:
            raise StorageError(
                f"Не удалось восстановить сессию {session_id}: {exc}"
            ) from exc

    def list_sessions(self, variant_id=None):
        try:
            with self._connection() as db:
                if variant_id:
                    rows = db.execute("""
                        SELECT session_id, variant_id, status, created_at
                        FROM diagnostic_sessions
                        WHERE variant_id = ?
                        ORDER BY created_at DESC
                    """, (variant_id,)).fetchall()
                else:
                    rows = db.execute("""
                        SELECT session_id, variant_id, status, created_at
                        FROM diagnostic_sessions
                        ORDER BY created_at DESC
                    """).fetchall()

            return [dict(row) for row in rows]

        except sqlite3.Error as exc:
            raise StorageError(
                f"Ошибка получения списка сессий: {exc}"
            ) from exc

    def check_integrity(self):
        try:
            with self._connection() as db:
                rows = db.execute(
                    "PRAGMA integrity_check"
                ).fetchall()

            return [row[0] for row in rows]

        except sqlite3.Error as exc:
            raise StorageError(
                f"Ошибка проверки SQLite: {exc}"
            ) from exc
