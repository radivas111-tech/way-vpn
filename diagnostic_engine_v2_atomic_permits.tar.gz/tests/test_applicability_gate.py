import unittest

from applicability_registry import (
    ApplicabilityRegistry,
    ApplicabilityRecord,
    ApplicabilityStatus,
)
from applicability_gate import ApplicabilityGate


VARIANT = "TEST-VARIANT-001"
TEST_ID = "MISFIRE_COUNTERS"


class ApplicabilityGateTests(unittest.TestCase):

    def test_missing_record_is_unknown_and_blocked(self):
        gate = ApplicabilityGate()
        result = gate.evaluate(VARIANT, TEST_ID)

        self.assertEqual(result.status, ApplicabilityStatus.UNKNOWN)
        self.assertFalse(result.allowed)

    def test_verified_record_is_allowed(self):
        registry = ApplicabilityRegistry.test_fixture(
            VARIANT, [TEST_ID]
        )
        result = ApplicabilityGate(registry).evaluate(
            VARIANT, TEST_ID
        )

        self.assertEqual(
            result.status,
            ApplicabilityStatus.VERIFIED_APPLICABLE,
        )
        self.assertTrue(result.allowed)

    def test_not_applicable_is_blocked(self):
        registry = ApplicabilityRegistry([ApplicabilityRecord(
            VARIANT,
            TEST_ID,
            ApplicabilityStatus.NOT_APPLICABLE,
        )])

        result = ApplicabilityGate(registry).evaluate(VARIANT, TEST_ID)

        self.assertFalse(result.allowed)
        self.assertEqual(
            result.status,
            ApplicabilityStatus.NOT_APPLICABLE,
        )

    def test_procedure_required_is_blocked(self):
        registry = ApplicabilityRegistry([ApplicabilityRecord(
            VARIANT,
            TEST_ID,
            ApplicabilityStatus.PROCEDURE_REQUIRED,
        )])

        result = ApplicabilityGate(registry).evaluate(VARIANT, TEST_ID)

        self.assertFalse(result.allowed)
        self.assertEqual(
            result.status,
            ApplicabilityStatus.PROCEDURE_REQUIRED,
        )

    def test_safety_blocked_is_blocked(self):
        registry = ApplicabilityRegistry([ApplicabilityRecord(
            VARIANT,
            TEST_ID,
            ApplicabilityStatus.SAFETY_BLOCKED,
        )])

        result = ApplicabilityGate(registry).evaluate(VARIANT, TEST_ID)

        self.assertFalse(result.allowed)
        self.assertEqual(
            result.status,
            ApplicabilityStatus.SAFETY_BLOCKED,
        )

    def test_wrong_variant_is_unknown(self):
        registry = ApplicabilityRegistry.test_fixture(
            VARIANT, [TEST_ID]
        )

        result = ApplicabilityGate(registry).evaluate(
            "ANOTHER-VARIANT",
            TEST_ID,
        )

        self.assertFalse(result.allowed)
        self.assertEqual(result.status, ApplicabilityStatus.UNKNOWN)

    def test_incomplete_verified_record_is_rejected(self):
        registry = ApplicabilityRegistry([ApplicabilityRecord(
            variant_id=VARIANT,
            test_id=TEST_ID,
            status=ApplicabilityStatus.VERIFIED_APPLICABLE,
            procedure_id="",
            procedure_version="",
            source="",
            verification_status="unverified",
        )])

        result = ApplicabilityGate(registry).evaluate(VARIANT, TEST_ID)

        self.assertFalse(result.allowed)
        self.assertEqual(
            result.status,
            ApplicabilityStatus.PROCEDURE_REQUIRED,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
