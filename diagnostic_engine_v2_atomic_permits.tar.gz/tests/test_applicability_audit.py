import sqlite3
import tempfile
import unittest
from pathlib import Path

from applicability_audit import (
    ApplicabilityAudit,
    ApplicabilityAuditError,
)
from applicability_gate import ApplicabilityGate
from applicability_registry import ApplicabilityRegistry
from engine import DiagnosticEngine
from storage import SessionStorage


VARIANT = "AUDIT-TEST-VARIANT"


class ApplicabilityAuditTests(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        db_path = Path(self.temp_dir.name) / "audit.db"

        self.storage = SessionStorage(db_path)
        self.audit = ApplicabilityAudit(db_path)

        registry = ApplicabilityRegistry.test_fixture(
            VARIANT,
            ["MISFIRE_COUNTERS"],
        )
        self.gate = ApplicabilityGate(registry)

        self.engine = DiagnosticEngine(
            storage=self.storage,
            applicability_gate=self.gate,
        )

        self.session = self.engine.create_session(
            VARIANT,
            dtcs=["P0300"],
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_issue_permit_creates_event(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        permit_id = self.audit.issue_permit(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        permit = self.audit.get_permit(permit_id)
        events = self.audit.get_events(permit_id=permit_id)

        self.assertEqual(permit["status"], "ISSUED")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["event_type"], "PERMIT_ISSUED")

    def test_permit_recheck_and_consumption(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        permit_id = self.audit.issue_permit(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        self.audit.record_recheck(permit_id, decision)
        self.audit.consume_permit(permit_id)

        permit = self.audit.get_permit(permit_id)
        events = self.audit.get_events(permit_id=permit_id)

        self.assertEqual(permit["status"], "CONSUMED")
        self.assertEqual(
            [item["event_type"] for item in events],
            [
                "PERMIT_ISSUED",
                "PERMIT_RECHECK_ALLOWED",
                "PERMIT_CONSUMED",
            ],
        )

    def test_consumed_permit_cannot_be_reused(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        permit_id = self.audit.issue_permit(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        self.audit.consume_permit(permit_id)

        with self.assertRaises(ApplicabilityAuditError):
            self.audit.consume_permit(permit_id)

    def test_denied_decision_is_logged(self):
        closed_gate = ApplicabilityGate()
        decision = closed_gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        self.audit.record_denied(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        events = self.audit.get_events(
            session_id=self.session.session_id
        )

        self.assertEqual(events[-1]["event_type"], "PERMIT_DENIED")
        self.assertIsNone(events[-1]["permit_id"])

    def test_missing_session_cannot_receive_permit(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        with self.assertRaises(ApplicabilityAuditError):
            self.audit.issue_permit(
                "MISSING-SESSION",
                VARIANT,
                "MISFIRE_COUNTERS",
                decision,
            )

    def test_audit_events_cannot_be_updated(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        permit_id = self.audit.issue_permit(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        event = self.audit.get_events(permit_id=permit_id)[0]

        with self.assertRaises(sqlite3.IntegrityError):
            with self.audit.connect() as db:
                db.execute("""
                    UPDATE applicability_audit_events
                    SET reason = 'tampered'
                    WHERE event_id = ?
                """, (event["event_id"],))

    def test_audit_events_cannot_be_deleted(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        permit_id = self.audit.issue_permit(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        event = self.audit.get_events(permit_id=permit_id)[0]

        with self.assertRaises(sqlite3.IntegrityError):
            with self.audit.connect() as db:
                db.execute("""
                    DELETE FROM applicability_audit_events
                    WHERE event_id = ?
                """, (event["event_id"],))

    def test_permit_survives_audit_reinitialization(self):
        decision = self.gate.evaluate(
            VARIANT,
            "MISFIRE_COUNTERS",
        )

        permit_id = self.audit.issue_permit(
            self.session.session_id,
            VARIANT,
            "MISFIRE_COUNTERS",
            decision,
        )

        restored_audit = ApplicabilityAudit(self.storage.db_path)
        permit = restored_audit.get_permit(permit_id)

        self.assertIsNotNone(permit)
        self.assertEqual(permit["status"], "ISSUED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
