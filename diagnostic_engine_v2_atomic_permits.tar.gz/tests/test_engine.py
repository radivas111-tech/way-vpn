import unittest

from engine import DiagnosticEngine, DiagnosticError
from applicability_registry import ApplicabilityRegistry
from applicability_gate import ApplicabilityGate
from knowledge import TEST_CATALOG


VARIANT = "TEST-VARIANT-001"


def make_engine():
    registry = ApplicabilityRegistry.test_fixture(
        VARIANT,
        list(TEST_CATALOG),
    )
    return DiagnosticEngine(
        applicability_gate=ApplicabilityGate(registry)
    )


class DiagnosticEngineTests(unittest.TestCase):

    def setUp(self):
        self.engine = make_engine()

    def test_variant_is_mandatory(self):
        with self.assertRaises(DiagnosticError):
            self.engine.create_session("")

    def test_multiple_hypotheses(self):
        session = self.engine.create_session(
            variant_id=VARIANT,
            symptoms=["engine_shaking", "rough_idle"],
            dtcs=["P0300", "P0171"],
        )
        self.assertGreaterEqual(len(session.hypotheses), 2)

    def test_next_test_is_selected(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        test = self.engine.get_next_test(session)
        self.assertEqual(test["test_id"], "MISFIRE_COUNTERS")
        self.assertEqual(
            test["selection"]["applicability"],
            "VERIFIED_APPLICABLE",
        )

    def test_positive_result_updates_hypothesis(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        before = session.hypotheses[0].priority
        self.engine.get_next_test(session)

        result = self.engine.submit_test_result(
            session,
            "MISFIRE_COUNTERS",
            "positive",
            "Тестовое наблюдение",
        )

        self.assertGreater(session.hypotheses[0].priority, before)
        self.assertEqual(len(result["quality_payloads"]), 1)

    def test_negative_result_reduces_priority(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        before = session.hypotheses[0].priority
        self.engine.get_next_test(session)

        self.engine.submit_test_result(
            session,
            "MISFIRE_COUNTERS",
            "negative",
        )

        self.assertLess(session.hypotheses[0].priority, before)

    def test_duplicate_test_is_rejected(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        self.engine.get_next_test(session)

        self.engine.submit_test_result(
            session,
            "MISFIRE_COUNTERS",
            "positive",
        )

        with self.assertRaises(DiagnosticError):
            self.engine.submit_test_result(
                session,
                "MISFIRE_COUNTERS",
                "negative",
            )

    def test_unknown_test_is_rejected(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])

        with self.assertRaises(DiagnosticError):
            self.engine.submit_test_result(
                session,
                "UNKNOWN",
                "positive",
            )

    def test_diagnosis_is_never_auto_confirmed(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        report = self.engine.get_report(session)

        self.assertIn("не подтверждён", report["conclusion"])
        self.assertTrue(
            all(h.status == "unconfirmed" for h in session.hypotheses)
        )

    def test_direct_submit_without_gate_permit_is_blocked(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])

        with self.assertRaises(DiagnosticError):
            self.engine.submit_test_result(
                session,
                "MISFIRE_COUNTERS",
                "positive",
            )

    def test_default_engine_is_closed(self):
        engine = DiagnosticEngine()
        session = engine.create_session(VARIANT, dtcs=["P0300"])

        self.assertIsNone(engine.get_next_test(session))

    def test_gate_rechecked_before_submit(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        self.engine.get_next_test(session)

        self.engine.applicability_gate.registry.clear()

        with self.assertRaises(DiagnosticError):
            self.engine.submit_test_result(
                session,
                "MISFIRE_COUNTERS",
                "positive",
            )

    def test_permit_cannot_be_reused_for_another_variant(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        self.engine.get_next_test(session)

        session.variant_id = "ANOTHER-VARIANT"

        with self.assertRaises(DiagnosticError):
            self.engine.submit_test_result(
                session,
                "MISFIRE_COUNTERS",
                "positive",
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
