import tempfile
import unittest
from pathlib import Path

from engine import DiagnosticEngine
from storage import SessionStorage
from applicability_registry import ApplicabilityRegistry
from applicability_gate import ApplicabilityGate


VARIANT = "TEST-VARIANT-001"


class StorageTests(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        db_path = Path(self.temp_dir.name) / "test.db"
        self.storage = SessionStorage(db_path)

        registry = ApplicabilityRegistry.test_fixture(
            VARIANT,
            ["MISFIRE_COUNTERS"],
        )

        self.engine = DiagnosticEngine(
            applicability_gate=ApplicabilityGate(registry)
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_restore_session(self):
        session = self.engine.create_session(
            VARIANT,
            symptoms=["engine_shaking"],
            dtcs=["P0300"],
        )

        self.storage.save_session(session)
        restored = self.storage.load_session(session.session_id)

        self.assertIsNotNone(restored)
        self.assertEqual(restored.session_id, session.session_id)
        self.assertEqual(restored.variant_id, session.variant_id)
        self.assertEqual(restored.dtcs, session.dtcs)
        self.assertEqual(len(restored.hypotheses), len(session.hypotheses))
        self.assertEqual(len(restored.evidence), len(session.evidence))

    def test_test_history_survives_restart(self):
        session = self.engine.create_session(
            VARIANT,
            dtcs=["P0300"],
        )

        selected = self.engine.get_next_test(session)
        self.assertIsNotNone(selected)
        self.assertEqual(selected["test_id"], "MISFIRE_COUNTERS")

        self.engine.submit_test_result(
            session,
            "MISFIRE_COUNTERS",
            "positive",
            "Тестовое наблюдение",
        )

        self.storage.save_session(session)
        restored = self.storage.load_session(session.session_id)

        self.assertEqual(len(restored.test_history), 1)
        self.assertEqual(
            restored.test_history[0]["result"],
            "positive",
        )

    def test_missing_session_returns_none(self):
        self.assertIsNone(
            self.storage.load_session("NONEXISTENT")
        )

    def test_session_listing(self):
        session = self.engine.create_session(
            VARIANT,
            dtcs=["P0300"],
        )

        self.storage.save_session(session)

        sessions = self.storage.list_sessions(VARIANT)

        self.assertEqual(len(sessions), 1)
        self.assertEqual(
            sessions[0]["session_id"],
            session.session_id,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
