import unittest

from engine import DiagnosticEngine
from test_selection import score_test
from applicability_registry import ApplicabilityRegistry
from applicability_gate import ApplicabilityGate
from knowledge import TEST_CATALOG


VARIANT = "TEST-VARIANT-001"


def make_engine():
    registry = ApplicabilityRegistry.test_fixture(
        VARIANT,
        list(TEST_CATALOG),
    )
    return DiagnosticEngine(
        applicability_gate=ApplicabilityGate(registry)
    )


class TestSelectionTests(unittest.TestCase):

    def setUp(self):
        self.engine = make_engine()

    def test_misfire_test_selection(self):
        session = self.engine.create_session(
            VARIANT,
            symptoms=["ENGINE_SHAKING"],
            dtcs=["P0300"],
        )

        selected = self.engine.get_next_test(session)

        self.assertIsNotNone(selected)
        self.assertEqual(selected["test_id"], "MISFIRE_COUNTERS")

    def test_completed_test_is_not_selected(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        self.engine.get_next_test(session)

        session.test_history.append({
            "test_id": "MISFIRE_COUNTERS",
            "result": "positive",
        })

        selected = self.engine.get_next_test(session)

        self.assertEqual(selected["test_id"], "IGNITION_CHECK")

    def test_high_risk_reduces_score(self):
        safe_score = score_test("ECT_LIVE_DATA", 1)
        risky_score = score_test("FUEL_PRESSURE", 1)

        self.assertGreater(safe_score, risky_score)

    def test_unknown_profile_returns_none(self):
        self.assertIsNone(score_test("UNKNOWN_TEST", 1))

    def test_score_is_not_probability(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        selected = self.engine.get_next_test(session)

        self.assertEqual(
            selected["selection"]["score_type"],
            "heuristic_not_probability",
        )

    def test_only_verified_tests_are_selected(self):
        session = self.engine.create_session(VARIANT, dtcs=["P0300"])
        selected = self.engine.get_next_test(session)

        self.assertEqual(
            selected["selection"]["applicability"],
            "VERIFIED_APPLICABLE",
        )

    def test_closed_gate_returns_no_test(self):
        engine = DiagnosticEngine()
        session = engine.create_session(VARIANT, dtcs=["P0300"])

        self.assertIsNone(engine.get_next_test(session))


if __name__ == "__main__":
    unittest.main(verbosity=2)
