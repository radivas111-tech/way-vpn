from dataclasses import dataclass

from applicability_registry import (
    ApplicabilityStatus,
    ApplicabilityRegistry,
)


@dataclass(frozen=True)
class GateDecision:
    status: ApplicabilityStatus
    allowed: bool
    reason: str
    procedure_id: str = ""
    procedure_version: str = ""
    source: str = ""

    def to_dict(self):
        return {
            "status": self.status.value,
            "allowed": self.allowed,
            "reason": self.reason,
            "procedure_id": self.procedure_id,
            "procedure_version": self.procedure_version,
            "source": self.source,
        }


class ApplicabilityGate:

    def __init__(self, registry=None):
        self.registry = registry or ApplicabilityRegistry()

    def evaluate(self, variant_id, test_id):
        if not variant_id or not test_id:
            return GateDecision(
                ApplicabilityStatus.UNKNOWN,
                False,
                "Не указан variant_id или test_id.",
            )

        record = self.registry.get(variant_id, test_id)

        if record is None:
            return GateDecision(
                ApplicabilityStatus.UNKNOWN,
                False,
                "Для этой модификации и теста нет записи в реестре.",
            )

        if record.status == ApplicabilityStatus.NOT_APPLICABLE:
            return GateDecision(
                ApplicabilityStatus.NOT_APPLICABLE,
                False,
                "Тест неприменим к указанной модификации.",
            )

        if record.status == ApplicabilityStatus.SAFETY_BLOCKED:
            return GateDecision(
                ApplicabilityStatus.SAFETY_BLOCKED,
                False,
                "Выполнение теста заблокировано требованиями безопасности.",
            )

        if record.status == ApplicabilityStatus.PROCEDURE_REQUIRED:
            return GateDecision(
                ApplicabilityStatus.PROCEDURE_REQUIRED,
                False,
                "Для теста требуется подтверждённая процедура.",
            )

        if record.status != ApplicabilityStatus.VERIFIED_APPLICABLE:
            return GateDecision(
                ApplicabilityStatus.UNKNOWN,
                False,
                "Статус применимости неизвестен.",
            )

        metadata_valid = all((
            record.procedure_id.strip(),
            record.procedure_version.strip(),
            record.source.strip(),
            record.verification_status.strip().lower() == "verified",
        ))

        if not metadata_valid:
            return GateDecision(
                ApplicabilityStatus.PROCEDURE_REQUIRED,
                False,
                "Недостаточно данных для подтверждения процедуры.",
            )

        return GateDecision(
            ApplicabilityStatus.VERIFIED_APPLICABLE,
            True,
            "Применимость подтверждена записью реестра.",
            procedure_id=record.procedure_id,
            procedure_version=record.procedure_version,
            source=record.source,
        )
