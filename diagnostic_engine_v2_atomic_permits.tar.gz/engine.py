from copy import deepcopy
from datetime import datetime, timezone

from models import (
    DiagnosticSession,
    DiagnosticEvidence,
    EvidenceStatus,
    Hypothesis,
    new_id,
)
from knowledge import RULES, TEST_CATALOG
from quality_bridge import build_quality_payload
from applicability_gate import ApplicabilityGate
from applicability_registry import ApplicabilityStatus


class DiagnosticError(Exception):
    pass


class DiagnosticEngine:

    def __init__(self, storage=None, applicability_gate=None):
        self.storage = storage
        self.applicability_gate = (
            applicability_gate
            if applicability_gate is not None
            else ApplicabilityGate()
        )
        self._issued_permits = {}

    def save_session(self, session):
        if self.storage is None:
            raise DiagnosticError("SQLite Storage не подключён.")

        return self.storage.save_session(session)

    def load_session(self, session_id):
        if self.storage is None:
            raise DiagnosticError("SQLite Storage не подключён.")

        return self.storage.load_session(session_id)

    def create_session(
        self,
        variant_id,
        symptoms=None,
        dtcs=None,
        measurements=None,
    ):
        if not isinstance(variant_id, str) or not variant_id.strip():
            raise DiagnosticError("Точный variant_id обязателен.")

        symptoms = self._normalize(symptoms or [])
        dtcs = self._normalize(dtcs or [])

        session = DiagnosticSession(
            session_id=new_id("SESSION"),
            variant_id=variant_id.strip(),
            symptoms=symptoms,
            dtcs=dtcs,
            measurements=measurements or {},
        )

        for code in dtcs:
            session.evidence.append(DiagnosticEvidence(
                evidence_id=new_id("EVIDENCE"),
                session_id=session.session_id,
                variant_id=session.variant_id,
                evidence_type="dtc",
                description=f"Получен диагностический код {code}",
                value=code,
                status=EvidenceStatus.OBSERVED,
            ))

        for symptom in symptoms:
            session.evidence.append(DiagnosticEvidence(
                evidence_id=new_id("EVIDENCE"),
                session_id=session.session_id,
                variant_id=session.variant_id,
                evidence_type="symptom",
                description=f"Заявлен симптом: {symptom}",
                value=symptom,
                status=EvidenceStatus.OBSERVED,
            ))

        session.hypotheses = self._build_hypotheses(session)

        if self.storage is not None:
            self.save_session(session)

        return session

    @staticmethod
    def _normalize(values):
        return list(dict.fromkeys(
            str(value).strip().upper()
            for value in values
            if str(value).strip()
        ))

    def _build_hypotheses(self, session):
        hypotheses = []

        for rule in RULES:
            matching_dtcs = sorted(
                set(session.dtcs) & set(rule["dtcs"])
            )
            matching_symptoms = sorted(
                set(session.symptoms) & set(rule["symptoms"])
            )

            if not matching_dtcs and not matching_symptoms:
                continue

            score = min(
                0.95,
                0.20
                + 0.35 * bool(matching_dtcs)
                + 0.15 * bool(matching_symptoms)
                + 0.05 * max(0, len(matching_dtcs) - 1)
                + 0.03 * max(0, len(matching_symptoms) - 1),
            )

            supporting = [
                f"DTC:{code}" for code in matching_dtcs
            ]
            supporting += [
                f"SYMPTOM:{item}" for item in matching_symptoms
            ]

            hypotheses.append(Hypothesis(
                hypothesis_id=f"HYP-{rule['id']}",
                title=rule["title"],
                description=rule["description"],
                possible_causes=list(rule["causes"]),
                supporting_evidence=supporting,
                priority=round(score, 2),
                recommended_test_ids=list(rule["tests"]),
            ))

        return sorted(
            hypotheses,
            key=lambda h: h.priority,
            reverse=True,
        )

    def _issue_permit(self, session, test_id, decision):
        if not decision.allowed:
            return

        self._issued_permits.setdefault(
            session.session_id, {}
        )[test_id] = {
            "variant_id": session.variant_id,
            "status": decision.status.value,
            "procedure_id": decision.procedure_id,
            "procedure_version": decision.procedure_version,
            "source": decision.source,
        }

    def get_next_test(self, session):
        from test_selection import select_next_test

        return select_next_test(
            session,
            self.applicability_gate,
            on_permit=lambda test_id, decision: self._issue_permit(
                session, test_id, decision
            ),
        )

    def get_test_applicability(self, session):
        """Диагностическая информация о допуске без выдачи разрешения."""
        from test_selection import TEST_PROFILES

        results = []
        seen = set()

        for hypothesis in session.hypotheses:
            for test_id in hypothesis.recommended_test_ids:
                if test_id in seen or test_id not in TEST_CATALOG:
                    continue

                seen.add(test_id)
                decision = self.applicability_gate.evaluate(
                    session.variant_id,
                    test_id,
                )

                results.append({
                    "test_id": test_id,
                    "status": decision.status.value,
                    "allowed": decision.allowed,
                    "reason": decision.reason,
                    "has_planning_profile": test_id in TEST_PROFILES,
                })

        return results

    def submit_test_result(
        self,
        session,
        test_id,
        result,
        notes="",
    ):
        if session.status != "active":
            raise DiagnosticError("Сессия не активна.")

        if test_id not in TEST_CATALOG:
            raise DiagnosticError(f"Неизвестный тест: {test_id}")

        if result not in {
            "positive",
            "negative",
            "inconclusive",
        }:
            raise DiagnosticError(
                "Допустимые результаты: positive, negative, inconclusive."
            )

        if any(
            item["test_id"] == test_id
            for item in session.test_history
        ):
            raise DiagnosticError("Этот тест уже зарегистрирован.")

        # Проверка допуска непосредственно перед регистрацией результата.
        decision = self.applicability_gate.evaluate(
            session.variant_id,
            test_id,
        )

        if not decision.allowed:
            raise DiagnosticError(
                "Vehicle Applicability Gate заблокировал тест: "
                f"{decision.status.value}. {decision.reason}"
            )

        permit = self._issued_permits.get(
            session.session_id, {}
        ).get(test_id)

        if permit is None:
            raise DiagnosticError(
                "Нет ранее выданного разрешения Gate для этой сессии. "
                "Сначала запросите get_next_test()."
            )

        if permit["variant_id"] != session.variant_id:
            raise DiagnosticError(
                "Разрешение выдано для другой модификации автомобиля."
            )

        if permit["status"] != ApplicabilityStatus.VERIFIED_APPLICABLE.value:
            raise DiagnosticError("Разрешение Gate недействительно.")

        if (
            permit["procedure_id"] != decision.procedure_id
            or permit["procedure_version"] != decision.procedure_version
            or permit["source"] != decision.source
        ):
            raise DiagnosticError(
                "Данные процедуры изменились после выдачи разрешения."
            )

        snapshot = deepcopy(session)

        try:
            test = TEST_CATALOG[test_id]

            session.test_history.append({
                "test_id": test_id,
                "result": result,
                "notes": notes,
                "recorded_at": datetime.now(timezone.utc).isoformat(),
                "applicability": {
                    "status": decision.status.value,
                    "procedure_id": decision.procedure_id,
                    "procedure_version": decision.procedure_version,
                    "source": decision.source,
                },
            })

            evidence = DiagnosticEvidence(
                evidence_id=new_id("EVIDENCE"),
                session_id=session.session_id,
                variant_id=session.variant_id,
                evidence_type="test_result",
                description=(
                    f"{test['title']}: {result}. {notes}"
                ).strip(),
                value={
                    "test_id": test_id,
                    "result": result,
                },
                status=EvidenceStatus.OBSERVED,
                source="diagnostic_test",
            )

            session.evidence.append(evidence)

            for hypothesis in session.hypotheses:
                if test_id not in hypothesis.recommended_test_ids:
                    continue

                if result == "positive":
                    hypothesis.supporting_evidence.append(
                        evidence.evidence_id
                    )
                    hypothesis.priority = min(
                        0.99,
                        hypothesis.priority + 0.10,
                    )

                elif result == "negative":
                    hypothesis.contradicting_evidence.append(
                        evidence.evidence_id
                    )
                    hypothesis.priority = max(
                        0.01,
                        hypothesis.priority - 0.15,
                    )

            session.hypotheses.sort(
                key=lambda h: h.priority,
                reverse=True,
            )

            if self.storage is not None:
                self.save_session(session)

            self._issued_permits.get(
                session.session_id, {}
            ).pop(test_id, None)

        except Exception:
            session.__dict__.clear()
            session.__dict__.update(deepcopy(snapshot.__dict__))
            raise

        return {
            "session_id": session.session_id,
            "recorded_evidence_id": evidence.evidence_id,
            "next_test": self.get_next_test(session),
            "hypotheses": self.get_hypotheses(session),
            "quality_payloads": [
                build_quality_payload(session, hypothesis)
                for hypothesis in session.hypotheses
            ],
            "notice": (
                "Результат зарегистрирован как наблюдение. "
                "Автоматическое подтверждение диагноза запрещено."
            ),
        }

    @staticmethod
    def get_hypotheses(session):
        return [
            {
                "hypothesis_id": h.hypothesis_id,
                "title": h.title,
                "description": h.description,
                "possible_causes": h.possible_causes,
                "priority": h.priority,
                "status": h.status,
                "supporting_evidence": h.supporting_evidence,
                "contradicting_evidence": h.contradicting_evidence,
            }
            for h in session.hypotheses
        ]

    def get_report(self, session):
        return {
            "session_id": session.session_id,
            "variant_id": session.variant_id,
            "status": session.status,
            "symptoms": session.symptoms,
            "dtcs": session.dtcs,
            "hypotheses": self.get_hypotheses(session),
            "next_test": self.get_next_test(session),
            "evidence_count": len(session.evidence),
            "test_count": len(session.test_history),
            "conclusion": (
                "Диагноз не подтверждён. Требуется выполнить "
                "предложенные проверки и оценить доказательства."
            ),
        }
