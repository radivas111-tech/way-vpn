from dataclasses import dataclass, field
from enum import Enum


class ApplicabilityStatus(str, Enum):
    VERIFIED_APPLICABLE = "VERIFIED_APPLICABLE"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    UNKNOWN = "UNKNOWN"
    PROCEDURE_REQUIRED = "PROCEDURE_REQUIRED"
    SAFETY_BLOCKED = "SAFETY_BLOCKED"


@dataclass(frozen=True)
class ApplicabilityRecord:
    variant_id: str
    test_id: str
    status: ApplicabilityStatus
    procedure_id: str = ""
    procedure_version: str = ""
    source: str = ""
    verification_status: str = ""
    safety_requirements: tuple[str, ...] = field(default_factory=tuple)


class ApplicabilityRegistry:

    def __init__(self, records=None):
        self._records = {}

        for record in records or []:
            self.register(record)

    def register(self, record):
        if not isinstance(record, ApplicabilityRecord):
            raise TypeError("Ожидается ApplicabilityRecord.")

        if not record.variant_id.strip():
            raise ValueError("variant_id обязателен.")

        if not record.test_id.strip():
            raise ValueError("test_id обязателен.")

        if not isinstance(record.status, ApplicabilityStatus):
            raise ValueError("Недопустимый статус применимости.")

        key = (record.variant_id, record.test_id)
        self._records[key] = record

    def get(self, variant_id, test_id):
        return self._records.get((variant_id, test_id))

    def clear(self):
        self._records.clear()

    @classmethod
    def test_fixture(cls, variant_id, test_ids):
        """Только искусственные записи для автоматических тестов."""
        registry = cls()

        for test_id in test_ids:
            registry.register(ApplicabilityRecord(
                variant_id=variant_id,
                test_id=test_id,
                status=ApplicabilityStatus.VERIFIED_APPLICABLE,
                procedure_id=f"TEST-FIXTURE-{test_id}",
                procedure_version="TEST-ONLY",
                source="AUTOMATED_TEST_FIXTURE",
                verification_status="verified",
            ))

        return registry
