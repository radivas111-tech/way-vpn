from knowledge import TEST_CATALOG


# Экспертные планировочные оценки, не измеренная точность тестов.
# Все шкалы: 1 — низкое значение, 5 — высокое.
TEST_PROFILES = {
    "MISFIRE_COUNTERS": {
        "diagnostic_value": 5, "time": 1, "cost": 1, "risk": 1,
    },
    "IGNITION_CHECK": {
        "diagnostic_value": 4, "time": 3, "cost": 2, "risk": 2,
    },
    "FUEL_TRIMS": {
        "diagnostic_value": 4, "time": 1, "cost": 1, "risk": 1,
    },
    "SMOKE_TEST": {
        "diagnostic_value": 4, "time": 2, "cost": 3, "risk": 1,
    },
    "FUEL_PRESSURE": {
        "diagnostic_value": 4, "time": 3, "cost": 3, "risk": 4,
    },
    "O2_SENSOR_COMPARISON": {
        "diagnostic_value": 4, "time": 2, "cost": 2, "risk": 2,
    },
    "EXHAUST_LEAK_CHECK": {
        "diagnostic_value": 3, "time": 2, "cost": 1, "risk": 2,
    },
    "ECT_LIVE_DATA": {
        "diagnostic_value": 4, "time": 1, "cost": 1, "risk": 1,
    },
    "ECT_WIRING_CHECK": {
        "diagnostic_value": 4, "time": 3, "cost": 2, "risk": 3,
    },
    "MAF_LIVE_DATA": {
        "diagnostic_value": 4, "time": 1, "cost": 1, "risk": 1,
    },
    "INTAKE_LEAK_CHECK": {
        "diagnostic_value": 3, "time": 2, "cost": 2, "risk": 1,
    },
}


def score_test(test_id, hypothesis_coverage):
    profile = TEST_PROFILES.get(test_id)

    if profile is None:
        return None

    score = (
        profile["diagnostic_value"] * 12
        + min(max(hypothesis_coverage - 1, 0), 3) * 4
        - profile["time"] * 2
        - profile["cost"] * 2
        - profile["risk"] * 5
    )

    return round(score, 2)


def select_next_test(session, applicability_gate, on_permit=None):
    completed = {
        item["test_id"] for item in session.test_history
    }

    coverage = {}

    for hypothesis in session.hypotheses:
        for test_id in hypothesis.recommended_test_ids:
            coverage[test_id] = coverage.get(test_id, 0) + 1

    candidates = []
    seen = set()

    for hypothesis in session.hypotheses:
        for test_id in hypothesis.recommended_test_ids:
            if test_id in completed or test_id in seen:
                continue

            seen.add(test_id)

            definition = TEST_CATALOG.get(test_id)
            profile = TEST_PROFILES.get(test_id)

            if not definition or not profile:
                continue

            decision = applicability_gate.evaluate(
                session.variant_id,
                test_id,
            )

            if not decision.allowed:
                continue

            test_score = score_test(
                test_id,
                coverage.get(test_id, 1),
            )

            candidates.append({
                "test_id": test_id,
                **definition,
                "related_hypothesis": hypothesis.hypothesis_id,
                "reason": (
                    "Тест выбран по эвристической оценке "
                    "диагностической ценности, охвата гипотез, "
                    "затрат времени, стоимости и риска. "
                    "Допуск отдельно подтверждён Vehicle Applicability Gate."
                ),
                "selection": {
                    "score": test_score,
                    "diagnostic_value": profile["diagnostic_value"],
                    "hypothesis_coverage": coverage.get(test_id, 1),
                    "time": profile["time"],
                    "cost": profile["cost"],
                    "risk": profile["risk"],
                    "applicability": decision.status.value,
                    "procedure_id": decision.procedure_id,
                    "procedure_version": decision.procedure_version,
                    "procedure_source": decision.source,
                    "score_type": "heuristic_not_probability",
                },
                "_gate_decision": decision,
            })

    if not candidates:
        return None

    candidates.sort(
        key=lambda item: (
            item["selection"]["score"],
            -item["selection"]["risk"],
            item["test_id"],
        ),
        reverse=True,
    )

    selected = candidates[0]

    # Разрешение выдаётся только выбранному лучшему кандидату.
    decision = selected.pop("_gate_decision")

    if on_permit is not None:
        on_permit(selected["test_id"], decision)

    return selected
