import json
import sqlite3
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path


ENGINE_VERSION = "diagnostic-engine-v2"


class ApplicabilityAuditError(Exception):
    pass


class ApplicabilityAudit:

    def __init__(self, db_path, permit_ttl_seconds=900):
        self.db_path = str(db_path)
        self.permit_ttl_seconds = int(permit_ttl_seconds)

        if self.permit_ttl_seconds <= 0:
            raise ValueError("permit_ttl_seconds должен быть положительным.")

        if self.db_path != ":memory:":
            Path(self.db_path).parent.mkdir(
                parents=True,
                exist_ok=True,
            )

        self.initialize()

    @staticmethod
    def _now():
        return datetime.now(timezone.utc)

    @staticmethod
    def _timestamp(value=None):
        return (value or ApplicabilityAudit._now()).isoformat()

    def connect(self):
        db = sqlite3.connect(
            self.db_path,
            timeout=15,
        )
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA busy_timeout = 15000")
        db.execute("PRAGMA foreign_keys = ON")
        return db

    def initialize(self):
        try:
            with self.connect() as db:
                if self.db_path != ":memory:":
                    db.execute("PRAGMA journal_mode = WAL")

                db.executescript("""
                    CREATE TABLE IF NOT EXISTS applicability_permits (
                        permit_id TEXT PRIMARY KEY,
                        session_id TEXT NOT NULL,
                        variant_id TEXT NOT NULL,
                        test_id TEXT NOT NULL,
                        procedure_id TEXT NOT NULL,
                        procedure_version TEXT NOT NULL,
                        source TEXT NOT NULL,
                        verification_status TEXT NOT NULL,
                        gate_status TEXT NOT NULL,
                        status TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        engine_version TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        expires_at TEXT NOT NULL,
                        consumed_at TEXT,
                        FOREIGN KEY(session_id)
                            REFERENCES diagnostic_sessions(session_id)
                            ON DELETE RESTRICT
                    );

                    CREATE INDEX IF NOT EXISTS
                    idx_applicability_permits_session_test
                    ON applicability_permits(
                        session_id, test_id, created_at
                    );

                    CREATE TABLE IF NOT EXISTS applicability_audit_events (
                        event_id TEXT PRIMARY KEY,
                        permit_id TEXT,
                        session_id TEXT NOT NULL,
                        variant_id TEXT NOT NULL,
                        test_id TEXT NOT NULL,
                        event_type TEXT NOT NULL,
                        gate_status TEXT NOT NULL,
                        procedure_id TEXT NOT NULL,
                        procedure_version TEXT NOT NULL,
                        source TEXT NOT NULL,
                        verification_status TEXT NOT NULL,
                        reason TEXT NOT NULL,
                        engine_version TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        snapshot_json TEXT NOT NULL,
                        FOREIGN KEY(permit_id)
                            REFERENCES applicability_permits(permit_id)
                            ON DELETE RESTRICT,
                        FOREIGN KEY(session_id)
                            REFERENCES diagnostic_sessions(session_id)
                            ON DELETE RESTRICT
                    );

                    CREATE INDEX IF NOT EXISTS
                    idx_applicability_events_session
                    ON applicability_audit_events(session_id, created_at);

                    CREATE INDEX IF NOT EXISTS
                    idx_applicability_events_permit
                    ON applicability_audit_events(permit_id, created_at);

                    CREATE TRIGGER IF NOT EXISTS
                    applicability_events_no_update
                    BEFORE UPDATE ON applicability_audit_events
                    BEGIN
                        SELECT RAISE(
                            ABORT,
                            'Applicability audit events are immutable'
                        );
                    END;

                    CREATE TRIGGER IF NOT EXISTS
                    applicability_events_no_delete
                    BEFORE DELETE ON applicability_audit_events
                    BEGIN
                        SELECT RAISE(
                            ABORT,
                            'Applicability audit events are immutable'
                        );
                    END;

                    CREATE TRIGGER IF NOT EXISTS
                    applicability_permits_no_delete
                    BEFORE DELETE ON applicability_permits
                    BEGIN
                        SELECT RAISE(
                            ABORT,
                            'Applicability permits cannot be deleted'
                        );
                    END;
                """)

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Ошибка инициализации журнала допуска: {exc}"
            ) from exc

    @staticmethod
    def _decision_data(decision):
        status = getattr(decision.status, "value", decision.status)

        return {
            "gate_status": str(status),
            "allowed": bool(decision.allowed),
            "procedure_id": str(decision.procedure_id or ""),
            "procedure_version": str(
                decision.procedure_version or ""
            ),
            "source": str(decision.source or ""),
            "verification_status": str(
                getattr(decision, "verification_status", "") or ""
            ),
            "reason": str(decision.reason or ""),
        }

    @staticmethod
    def _insert_event(
        db,
        *,
        permit_id,
        session_id,
        variant_id,
        test_id,
        event_type,
        decision_data,
        reason,
        engine_version,
        created_at,
    ):
        snapshot = {
            "permit_id": permit_id,
            "session_id": session_id,
            "variant_id": variant_id,
            "test_id": test_id,
            "event_type": event_type,
            **decision_data,
            "reason": reason,
            "engine_version": engine_version,
            "created_at": created_at,
        }

        db.execute("""
            INSERT INTO applicability_audit_events (
                event_id,
                permit_id,
                session_id,
                variant_id,
                test_id,
                event_type,
                gate_status,
                procedure_id,
                procedure_version,
                source,
                verification_status,
                reason,
                engine_version,
                created_at,
                snapshot_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            f"AUDIT-{uuid.uuid4().hex}",
            permit_id,
            session_id,
            variant_id,
            test_id,
            event_type,
            decision_data["gate_status"],
            decision_data["procedure_id"],
            decision_data["procedure_version"],
            decision_data["source"],
            decision_data["verification_status"],
            reason,
            engine_version,
            created_at,
            json.dumps(
                snapshot,
                ensure_ascii=False,
                separators=(",", ":"),
                allow_nan=False,
            ),
        ))

    def issue_permit(
        self,
        session_id,
        variant_id,
        test_id,
        decision,
        engine_version=ENGINE_VERSION,
    ):
        data = self._decision_data(decision)

        if not data["allowed"]:
            raise ApplicabilityAuditError(
                "Нельзя выдать разрешение: Gate заблокировал тест."
            )

        if data["gate_status"] != "VERIFIED_APPLICABLE":
            raise ApplicabilityAuditError(
                "Разрешение допускается только для VERIFIED_APPLICABLE."
            )

        required = (
            data["procedure_id"],
            data["procedure_version"],
            data["source"],
        )

        if not all(required):
            raise ApplicabilityAuditError(
                "В разрешении отсутствуют данные процедуры или источника."
            )

        now = self._now()
        created_at = self._timestamp(now)
        expires_at = self._timestamp(
            now + timedelta(seconds=self.permit_ttl_seconds)
        )
        permit_id = f"PERMIT-{uuid.uuid4().hex}"

        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")

                # Старые неиспользованные разрешения заменяются.
                old_permits = db.execute("""
                    SELECT *
                    FROM applicability_permits
                    WHERE session_id = ?
                      AND test_id = ?
                      AND status = 'ISSUED'
                """, (session_id, test_id)).fetchall()

                for old in old_permits:
                    db.execute("""
                        UPDATE applicability_permits
                        SET status = 'INVALIDATED'
                        WHERE permit_id = ?
                    """, (old["permit_id"],))

                    old_data = {
                        "gate_status": old["gate_status"],
                        "allowed": False,
                        "procedure_id": old["procedure_id"],
                        "procedure_version": old["procedure_version"],
                        "source": old["source"],
                        "verification_status": old["verification_status"],
                    }

                    self._insert_event(
                        db,
                        permit_id=old["permit_id"],
                        session_id=old["session_id"],
                        variant_id=old["variant_id"],
                        test_id=old["test_id"],
                        event_type="PERMIT_INVALIDATED",
                        decision_data=old_data,
                        reason="Заменено новым разрешением.",
                        engine_version=engine_version,
                        created_at=created_at,
                    )

                db.execute("""
                    INSERT INTO applicability_permits (
                        permit_id,
                        session_id,
                        variant_id,
                        test_id,
                        procedure_id,
                        procedure_version,
                        source,
                        verification_status,
                        gate_status,
                        status,
                        reason,
                        engine_version,
                        created_at,
                        expires_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ISSUED',
                            ?, ?, ?, ?)
                """, (
                    permit_id,
                    session_id,
                    variant_id,
                    test_id,
                    data["procedure_id"],
                    data["procedure_version"],
                    data["source"],
                    data["verification_status"],
                    data["gate_status"],
                    data["reason"],
                    engine_version,
                    created_at,
                    expires_at,
                ))

                self._insert_event(
                    db,
                    permit_id=permit_id,
                    session_id=session_id,
                    variant_id=variant_id,
                    test_id=test_id,
                    event_type="PERMIT_ISSUED",
                    decision_data=data,
                    reason=data["reason"],
                    engine_version=engine_version,
                    created_at=created_at,
                )

            return permit_id

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось выдать разрешение: {exc}"
            ) from exc

    def get_active_permit(self, session_id, test_id):
        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")

                row = db.execute("""
                    SELECT *
                    FROM applicability_permits
                    WHERE session_id = ?
                      AND test_id = ?
                      AND status = 'ISSUED'
                    ORDER BY created_at DESC
                    LIMIT 1
                """, (session_id, test_id)).fetchone()

                if row is None:
                    return None

                if self._now() >= datetime.fromisoformat(
                    row["expires_at"]
                ):
                    db.execute("""
                        UPDATE applicability_permits
                        SET status = 'EXPIRED'
                        WHERE permit_id = ?
                    """, (row["permit_id"],))

                    data = {
                        "gate_status": row["gate_status"],
                        "allowed": False,
                        "procedure_id": row["procedure_id"],
                        "procedure_version": row["procedure_version"],
                        "source": row["source"],
                        "verification_status": row[
                            "verification_status"
                        ],
                    }

                    self._insert_event(
                        db,
                        permit_id=row["permit_id"],
                        session_id=row["session_id"],
                        variant_id=row["variant_id"],
                        test_id=row["test_id"],
                        event_type="PERMIT_EXPIRED",
                        decision_data=data,
                        reason="Истёк срок действия разрешения.",
                        engine_version=row["engine_version"],
                        created_at=self._timestamp(),
                    )
                    return None

                return dict(row)

        except (sqlite3.Error, ValueError) as exc:
            raise ApplicabilityAuditError(
                f"Ошибка чтения разрешения: {exc}"
            ) from exc

    def record_recheck(self, permit_id, decision):
        data = self._decision_data(decision)
        event_type = (
            "PERMIT_RECHECK_ALLOWED"
            if data["allowed"]
            else "PERMIT_RECHECK_DENIED"
        )

        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")

                row = db.execute("""
                    SELECT *
                    FROM applicability_permits
                    WHERE permit_id = ?
                """, (permit_id,)).fetchone()

                if row is None or row["status"] != "ISSUED":
                    raise ApplicabilityAuditError(
                        "Разрешение отсутствует или уже недействительно."
                    )

                self._insert_event(
                    db,
                    permit_id=permit_id,
                    session_id=row["session_id"],
                    variant_id=row["variant_id"],
                    test_id=row["test_id"],
                    event_type=event_type,
                    decision_data=data,
                    reason=data["reason"],
                    engine_version=row["engine_version"],
                    created_at=self._timestamp(),
                )

                if not data["allowed"]:
                    db.execute("""
                        UPDATE applicability_permits
                        SET status = 'INVALIDATED'
                        WHERE permit_id = ?
                    """, (permit_id,))

            return event_type

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось записать повторную проверку: {exc}"
            ) from exc

    def invalidate_permit(self, permit_id, reason):
        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")

                row = db.execute("""
                    SELECT *
                    FROM applicability_permits
                    WHERE permit_id = ?
                """, (permit_id,)).fetchone()

                if row is None or row["status"] != "ISSUED":
                    raise ApplicabilityAuditError(
                        "Нельзя аннулировать отсутствующее или закрытое разрешение."
                    )

                db.execute("""
                    UPDATE applicability_permits
                    SET status = 'INVALIDATED'
                    WHERE permit_id = ?
                """, (permit_id,))

                data = {
                    "gate_status": row["gate_status"],
                    "allowed": False,
                    "procedure_id": row["procedure_id"],
                    "procedure_version": row["procedure_version"],
                    "source": row["source"],
                    "verification_status": row["verification_status"],
                }

                self._insert_event(
                    db,
                    permit_id=permit_id,
                    session_id=row["session_id"],
                    variant_id=row["variant_id"],
                    test_id=row["test_id"],
                    event_type="PERMIT_INVALIDATED",
                    decision_data=data,
                    reason=str(reason),
                    engine_version=row["engine_version"],
                    created_at=self._timestamp(),
                )

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось аннулировать разрешение: {exc}"
            ) from exc

    def consume_permit(self, permit_id):
        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")

                row = db.execute("""
                    SELECT *
                    FROM applicability_permits
                    WHERE permit_id = ?
                """, (permit_id,)).fetchone()

                if row is None or row["status"] != "ISSUED":
                    raise ApplicabilityAuditError(
                        "Разрешение нельзя использовать повторно."
                    )

                now = self._now()

                if now >= datetime.fromisoformat(row["expires_at"]):
                    raise ApplicabilityAuditError(
                        "Срок действия разрешения истёк."
                    )

                db.execute("""
                    UPDATE applicability_permits
                    SET status = 'CONSUMED',
                        consumed_at = ?
                    WHERE permit_id = ?
                """, (self._timestamp(now), permit_id))

                data = {
                    "gate_status": row["gate_status"],
                    "allowed": True,
                    "procedure_id": row["procedure_id"],
                    "procedure_version": row["procedure_version"],
                    "source": row["source"],
                    "verification_status": row["verification_status"],
                }

                self._insert_event(
                    db,
                    permit_id=permit_id,
                    session_id=row["session_id"],
                    variant_id=row["variant_id"],
                    test_id=row["test_id"],
                    event_type="PERMIT_CONSUMED",
                    decision_data=data,
                    reason="Разрешение использовано для регистрации результата.",
                    engine_version=row["engine_version"],
                    created_at=self._timestamp(now),
                )

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось использовать разрешение: {exc}"
            ) from exc

    def record_denied(
        self,
        session_id,
        variant_id,
        test_id,
        decision,
        engine_version=ENGINE_VERSION,
    ):
        data = self._decision_data(decision)

        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")

                self._insert_event(
                    db,
                    permit_id=None,
                    session_id=session_id,
                    variant_id=variant_id,
                    test_id=test_id,
                    event_type="PERMIT_DENIED",
                    decision_data=data,
                    reason=data["reason"],
                    engine_version=engine_version,
                    created_at=self._timestamp(),
                )

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось записать отказ Gate: {exc}"
            ) from exc

    def get_events(self, session_id=None, permit_id=None):
        if session_id is None and permit_id is None:
            raise ValueError(
                "Укажите session_id или permit_id."
            )

        try:
            with self.connect() as db:
                if permit_id is not None:
                    rows = db.execute("""
                        SELECT *
                        FROM applicability_audit_events
                        WHERE permit_id = ?
                        ORDER BY created_at, event_id
                    """, (permit_id,)).fetchall()
                else:
                    rows = db.execute("""
                        SELECT *
                        FROM applicability_audit_events
                        WHERE session_id = ?
                        ORDER BY created_at, event_id
                    """, (session_id,)).fetchall()

            return [dict(row) for row in rows]

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось прочитать журнал: {exc}"
            ) from exc

    def get_permit(self, permit_id):
        try:
            with self.connect() as db:
                row = db.execute("""
                    SELECT *
                    FROM applicability_permits
                    WHERE permit_id = ?
                """, (permit_id,)).fetchone()

            return dict(row) if row else None

        except sqlite3.Error as exc:
            raise ApplicabilityAuditError(
                f"Не удалось прочитать разрешение: {exc}"
            ) from exc
